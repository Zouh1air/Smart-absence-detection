from django.shortcuts import render,redirect
from requests import request
from Administration.models import Student
from .models import StudentListe
from django.contrib.auth.forms import AuthenticationForm
import Recognize
import numpy as np 


def login(request):
    if request.method == 'POST':
        form=AuthenticationForm(data=request.POST)
        if form.is_valid():        
             return redirect('prof') 
    else:
        form=AuthenticationForm()
    return render(request,'prof/login-prof.html',context={'form':form})

def prof(request):
    return render(request,template_name='prof/classe.html')

def detection(request):
    a=Recognize.recognize_attendence()
    # b=Student.objects.all()
    # l=[]
    # for i in b:
    #     l.append(i)
    # ,'student':l
    return render(request,template_name='prof/tableau.html',context={'etudiant':a})

def classe(request):
    # x=request.GET('myclass')  
    # if x=='GIIA':
    # context={'Classe1':GIIA.objects.all()}
    return render(request,template_name='prof/tableau.html',context={'Absence': StudentListe.objects.all()})
    # elif x=='GTR':
    #     return render(request,template_name='prof/tableau.html',context={'classe1':GTR.objects.all()})

    # from rest_framework.decorators import api_view
    # from rest_framework.response import Response
    # from .serializers import ProfesseurSerializer
    # from .models import Professeur

    # @api_view(['GET'])
    # def allProfesseur(request):
    #     Prof=Professeur.objects.all()
    #     serialization=ProfesseurSerializer(Prof,many=True)
    #     return Response(serialization.data)


