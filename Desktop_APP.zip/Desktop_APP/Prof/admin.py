
import imp
from django.contrib import admin
# from .models import GIIA,GTR
from .models import StudentListe

admin.site.site_header='Smart-Absence'
admin.site.site_title='Smart-Absence'
admin.site.index_title='Welcome to Admin Area'



class Student_Admin(admin.ModelAdmin):
    list_display=['num','nom','prenom','presence']
    list_display_links=['nom','prenom']
    search_fields=['nom','prenom']
    list_filter=['prenom','nom']
    list_editable=['presence']
    
admin.site.register(StudentListe,Student_Admin)

# class GIIA_Admin(admin.ModelAdmin):
#     list_display=['nom','prenom','present']
#     list_display_links=['nom','prenom']
#     list_editable=['present']
#     search_fields=['nom','prenom']
#     list_filter=['prenom','nom']
    

# admin.site.register(GIIA,GIIA_Admin)


# class GTR_Admin(admin.ModelAdmin):
#     list_display=['nom','prenom','present']
#     list_display_links=['nom','prenom']
#     list_editable=['present']
#     search_fields=['nom','prenom']
#     list_filter=['prenom','nom']

# admin.site.register(GTR,GTR_Admin)
# from .models import Professeur
#admin.site.register(Professeur)