from django.db import models

# Create your models here.
from django.db import models
# from csvImporter.model import CsvDbModel


class StudentListe(models.Model):
    num=models.IntegerField(verbose_name='ID')
    prenom=models.CharField(max_length=50)
    nom=models.CharField(max_length=50)
    presence=models.BooleanField(default=False)
    def __str__(self):
        return self.nom
    class Meta:
        ordering=['nom']
        verbose_name='GIIA-Student'

# class GIIA(models.Model):
#     nom=models.CharField(max_length=20 , verbose_name='nom')
#     prenom=models.CharField(max_length=20 , verbose_name='prenom')
#     present=models.BooleanField()
#     class Meta:
#         ordering=['nom']
#         verbose_name='GIIA Etudiant'


# class GTR(models.Model):
#     nom=models.CharField(max_length=20, verbose_name='nom')
#     prenom=models.CharField(max_length=20, verbose_name='prenom')
#     present=models.BooleanField()
#     class Meta:
#         ordering=['nom']
#         verbose_name='GTR Etudiant'

# class Professeur(models.Model):
#      username=models.CharField(max_length=20)
#      email=models.CharField(max_length=100, null=True)
#      password=models.CharField(max_length=20)
     