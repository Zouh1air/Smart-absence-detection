from . import views 
from django.urls import path

urlpatterns = [
    path('login', views.login,name='login-prof'),
    path('prof', views.prof,name='prof'),
    #path('prof', views.allProfesseur,name='prof'),
    path('classe',views.classe,name='classe'),
    path('detection',views.detection,name='detection'),
]