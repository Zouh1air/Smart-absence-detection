from ast import Num
import csv

import cv2
import os
# import sqlite3
# conn=sqlite3.connect('sqlite3.db')
# cur=conn.cursor()
# req="select * from Student"
# result=cur.execute(req)
# for row in result:
#     id=row[0]
#     nom=row[1]
from Administration.models import Student

list=[]
def lastStudent():
    x=0
    a=Student.objects.all()
    # list.append(a)
    for i in a:
        list.append(i.num)
        list.append(i.prenom)
        list.append(i.nom)
    student=[list[len(list)-3],list[len(list)-2],list[len(list)-1]]
    return student
# counting the numbers

# etudiant=Student.objects.get(num=int(nbrStudent()))
# nom=Student.objects.get(nom='chebbab')

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False


# from Administration.models import Student
# Take image function

def takeImages():
    a=lastStudent()
    Id=a[0]
    prenom=a[1]
    name=a[2]
    # Id=etudiant.num
    # name=etudiant.prenom
    # Id = input('entrer un id :')
    # name = input('entrer votre nom :')
    # Id=id
    # name=nom

    if(is_number(Id) and name.isalpha() and prenom.isalpha()):
        cam = cv2.VideoCapture(0)
        harcascadePath = "haarcascade_frontalface_default.xml"
        detector = cv2.CascadeClassifier(harcascadePath)
        sampleNum = 0

        while(True):
            ret, img = cam.read()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(gray, 1.3, 5, minSize=(30,30),flags = cv2.CASCADE_SCALE_IMAGE)
            for(x,y,w,h) in faces:
                cv2.rectangle(img, (x, y), (x+w, y+h), (10, 159, 255), 2)
                #incrementing sample number
                sampleNum = sampleNum+1
                #saving the captured face in the dataset folder TrainingImage
                cv2.imwrite("TrainingImage"+os.sep +str(name)  + "." +str(Id)+ "."
                            +str(sampleNum) + ".jpg", gray[y:y+h, x:x+w])
                #display the frame
                cv2.imshow('frame', img)
            #wait for 100 miliseconds
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # break if the sample number is more than 100
            elif sampleNum > 100:
                break
        cam.release()
        cv2.destroyAllWindows()
        res = "Images Saved for ID : " + str(Id) + " Name : " + str(name)+"prenom :"+str(prenom)
        student=prenom +" "+ name
        row = [Id, student]
        with open("StudentDetails"+os.sep+"StudentDetails.csv", 'a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
    # else:
    #     if(is_number(Id)):
    #         print("Enter Alphabetical Name")
    #     if(name.isalpha()):
    #         print("Enter Numeric ID")
    

