from django.contrib import admin

# Register your models here.
from django.contrib import admin

# Register your models here.
from .models import Student



class Student_Admin(admin.ModelAdmin):
    list_display=['num','nom','prenom']
    list_display_links=['nom','prenom']
    search_fields=['nom','prenom']
    list_filter=['prenom','nom']
    
admin.site.register(Student,Student_Admin)