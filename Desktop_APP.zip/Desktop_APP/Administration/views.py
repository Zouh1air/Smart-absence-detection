from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect

from django.contrib.auth.forms import AuthenticationForm

from Administration.forms import StudentForm
# from sklearn.metrics import precision_recall_curve

# from .forms import EtudiantForm
from Administration.models import Student
import Capture_Image
# from Capture_Image import takeImages
import Train_Image

def login(request):
    if request.method == 'POST':
        form=AuthenticationForm(data=request.POST)
        if form.is_valid():        
             return redirect('administration')
    else:
        form=AuthenticationForm()
    return render(request,'administration/login-admin.html',context={'form':form})

def administration(request):
    return render(request,template_name='administration/administration.html')    

def training(request):
    Train_Image.TrainImages()
    return render(request,template_name='administration/training.html') 

# def add(request):
#     if request.method == 'POST':
#         # num=request.POST.get('num')
#         # prenom=request.POST.get('prenom')
#         # nom=request.POST.get('nom')
#         # data=Etudiant(num=num,prenom=prenom,nom=nom)
#         # if data.is_valid():
#         # data.save()
#         x=StudentForm(data=request.POST)
#         if x.is_valid():
#             x.save()
#         # Capture_Image.takeImages()
#     return render(request,template_name='administration/add.html') 
def add(request):
    # Capture_Image.takeImages()
    if request.method == 'POST':
        etudiant=StudentForm(data=request.POST)
        if etudiant.is_valid():
            etudiant.save()
            # addPhotos(request)
    return render(request,template_name='administration/add.html',context={'lf':StudentForm})

# import main
# def CaptureFaces():
#     Capture_Image.takeImages()
def addPhotos(request):
    # main.CaptureFaces()
    Capture_Image.takeImages()
    return render(request,template_name='administration/addphotos.html')


