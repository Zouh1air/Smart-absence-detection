from . import views 
from django.urls import path

urlpatterns = [
    path('', views.login,name='login-admin'),
    path('administration',views.administration,name='administration'),
    path('training',views.training,name='training'),
    path('addStudent',views.add,name='add'),
    path('addphotos',views.addPhotos,name='addphotos'),
]
