from django.db import models

from django.db import models

class Student(models.Model):
    num=models.IntegerField(verbose_name='ID')
    prenom=models.CharField(max_length=50)
    nom=models.CharField(max_length=50)
    def __str__(self):
        return self.nom
    class Meta:
        # ordering=['num']
        verbose_name='GIIA-Student'
